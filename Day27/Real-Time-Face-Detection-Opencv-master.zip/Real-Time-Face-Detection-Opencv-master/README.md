# Real-Time-Face-Detection-Opencv
RTFD is based on HOG (histogram oriented gradient) algorithm to detect face through webcam, This project is prepared under guideline of Pr. Praveen Kumar Chandaliya.
